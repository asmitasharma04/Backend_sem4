const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public'))); // Serve static files (HTML, CSS, JS)

// Serve the login/registration form (index.html)
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Handle user registration
app.post('/register', (req, res) => {
  const user = req.body;

  fs.readFile('data.json', 'utf8', (err, data) => {
    if (err) {
      return res.status(500).json({ success: false, error: "Failed to read data file" });
    }

    let users = data ? JSON.parse(data) : [];

    // Check if user already exists
    if (users.some(existingUser => existingUser.email === user.email)) {
      return res.status(400).json({ success: false, error: "User already exists" });
    }

    // Add the new user
    users.push(user);

    // Write the updated user data back to the file
    fs.writeFile('data.json', JSON.stringify(users, null, 2), (err) => {
      if (err) {
        return res.status(500).json({ success: false, error: "Failed to save data" });
      }
      return res.status(200).json({ success: true });
    });
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
