// Wait for the DOM to load completely before attaching event listeners
document.addEventListener('DOMContentLoaded', () => {
    // Handle the registration form submission
    document.getElementById('register-form').addEventListener('submit', function (e) {
      e.preventDefault(); // Prevent the form from submitting the traditional way
  
      // Collect the form data
      const username = document.getElementById('register-username').value;
      const rollno = document.getElementById('register-rollno').value;
      const university = document.getElementById('register-university').value;
      const email = document.getElementById('register-email').value;
      const password = document.getElementById('register-password').value;
      const dob = document.getElementById('register-dob').value;
      const fathername = document.getElementById('register-fathername').value;
      const mothername = document.getElementById('register-mothername').value;
      const country = document.getElementById('register-country').value;
      const contactno = document.getElementById('register-contactno').value;
  
      // Check if all fields are filled
      if (!username || !email || !password || !rollno || !university || !dob || !fathername || !mothername || !country || !contactno) {
        alert("Please fill in all fields.");
        return;
      }
  
      // Create an object with all the user data
      const userData = {
        username,
        rollno,
        university,
        email,
        password,
        dob,
        fathername,
        mothername,
        country,
        contactno
      };
  
      // Send a POST request to the server with the registration data
      fetch('/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData)
      })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            alert("Registration successful!");  // Show success alert
            document.getElementById('register-form').reset();  // Reset the form
          } else {
            alert(data.error || "Something went wrong!");
          }
        })
        .catch(error => {
          alert("Error: " + error);
        });
    });
  });
  